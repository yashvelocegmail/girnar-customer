import React from 'react'

export const api_url="http://localhost/girnar_backend/api/";
